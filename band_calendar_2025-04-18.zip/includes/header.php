<!DOCTYPE html>
<html lang="en" data-theme="light">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo $currNav; ?></title>
    <link rel="icon" href="../ico/favicon.ico" type="image/x-icon">
    <?php $ver = time(); ?>
    <link rel="stylesheet" href="css/reset.css">
    <link rel="stylesheet" href="css/style.css?v=<?php echo $ver; ?>">
    <script src="https://cdn.jsdelivr.net/npm/sortablejs@1.15.0/Sortable.min.js"></script>
    <script defer src="js/main.js?v=<?php echo $ver; ?>"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
</head>
<body>

<nav class="nav">
    <ul class="nav-list">
        <li>
            <a class="<?php if ($currNav == "Show List") { echo "is-active"; } ?>" href="index.php">
                <i class="fas fa-calendar-days"></i>
                <span class="nav-text">Calendar</span>
            </a>
        </li>
        <li>
            <a class="<?php if ($currNav == "New Show") { echo "is-active"; } ?>" href="new_show.php">
                <i class="fas fa-plus"></i>
                <span class="nav-text">New Show</span>
            </a>
        </li>
        <li>
            <a class="<?php if ($currNav == "Block Time") { echo "is-active"; } ?>" href="block_time.php">
                <i class="fas fa-ban"></i>
                <span class="nav-text">Block</span>
            </a>
        </li>
        <li>
            <a class="<?php if ($currNav == "Band List") { echo "is-active"; } ?>" href="band_list.php">
                <i class="fas fa-guitar"></i>
                <span class="nav-text">Bands</span>
            </a>
        </li>
        <li>
            <a class="<?php if ($currNav == "Venue List") { echo "is-active"; } ?>" href="venue_list.php">
                <i class="fas fa-location-dot"></i>
                <span class="nav-text">Venues</span>
            </a>
        </li>
    </ul>
</nav>

<main class="container">
