<?php
$link = mysqli_connect(DB_SERVER,DB_USER,DB_PASS,DB_NAME);
if (!$link) { die("Database connection failed: " . mysqli_error()); }
?>
