<?php
$DB_NAME="";
$DB_USER="";
$DB_PASS="";
define("DB_SERVER", "localhost");
define("DB_NAME", $DB_NAME);
define("DB_USER", $DB_USER);
define("DB_PASS", $DB_PASS);

$dbConnect=intval(1);

date_default_timezone_set('America/Los_Angeles');
$timeStamp = date("Y-m-d H:i:s");

//$KEY = getenv('ENCRYPTION_KEY');
?>