<?php
function toggleDir($dir) {
  return ($dir === 'asc') ? 'desc' : 'asc';
}

function sortIcon($column, $currentSort, $currentDir) {
  if ($column !== $currentSort) return 'fa-sort';
  return $currentDir === 'asc' ? 'fa-sort-up active-sort' : 'fa-sort-down active-sort';
}

?>