<?php
require_once("includes/constants.php");
require_once("includes/connection.php");
require_once("includes/functions.php");

$today = date('Y-m-d');
$showPast = isset($_GET['past']) && $_GET['past'] === '1';

$comparison = $showPast ? '<' : '>=';
$orderDir = $showPast ? 'DESC' : 'ASC';

$sql = "
    SELECT 
        shows.id, 
        shows.show_date, 
        shows.show_time, 
        venues.name AS venue_name, 
        GROUP_CONCAT(bands.name ORDER BY show_bands.slot_order SEPARATOR ', ') AS bands
    FROM shows
    LEFT JOIN venues ON shows.venue_id = venues.id
    LEFT JOIN show_bands ON shows.id = show_bands.show_id
    LEFT JOIN bands ON show_bands.band_id = bands.id
    WHERE shows.show_date $comparison ?
    GROUP BY shows.id
    ORDER BY shows.show_date $orderDir
";

$stmt = mysqli_prepare($link, $sql);
mysqli_stmt_bind_param($stmt, "s", $today);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

$currNav = "Show List";
require_once("includes/header.php");
?>

<div class="calendarWrap">

    <div id="calendarNav" class="custom-calendar-nav">
        <button id="prevCustom" class="nav-btn" aria-label="Previous Month">‹</button>
        <div id="customCalendarTitle" class="nav-title">Loading...</div>
        <button id="nextCustom" class="nav-btn" aria-label="Next Month">›</button>
    </div>

    <div id="custom-calendar">
        <div class="calendar-header">
            <div>Sun</div><div>Mon</div><div>Tue</div><div>Wed</div><div>Thu</div><div>Fri</div><div>Sat</div>
        </div>
        <div class="calendar-grid">
            <!-- JS will inject calendar days here -->
        </div>
    </div>

</div>

<section>

    <?php if ($showPast) { ?>
        <div class="show-divider">
            <hr>
            <a href="index.php" class="past-shows-btn">Current Shows</a>
            <hr>
        </div>
    <?php } ?>

    <div class="table-wrapper">
        <table class="table is-striped is-fullwidth">
            <thead>
                <tr>
                    <th>Date</th>
                    <th>Time</th>
                    <th>Venue</th>
                    <th class="hide-mobile">Bands</th>
                    <th></th>
                </tr>
            </thead>
            <tbody>
                <?php while ($row = mysqli_fetch_assoc($result)) : ?>
                    <tr>
                        <td><?= date('M j, Y', strtotime($row['show_date'])) ?></td>
                        <td><?= date('g:i A', strtotime($row['show_time'] ?? '')) ?></td>
                        <td><?= htmlspecialchars($row['venue_name'] ?? '') ?></td>
                        <td class="hide-mobile"><?= htmlspecialchars($row['bands'] ?? '') ?></td>
                        <td>
                            <a href="edit_show.php?id=<?= $row['id'] ?>" class="button btn-accent small">Edit</a>
                        </td>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>

    <?php if (!$showPast) { ?>
        <div class="show-divider">
            <hr>
            <a href="index.php?past=1" class="past-shows-btn">Past Shows</a>
            <hr>
        </div>
    <?php } ?>

</section>

<?php
require_once("includes/footer.php");
