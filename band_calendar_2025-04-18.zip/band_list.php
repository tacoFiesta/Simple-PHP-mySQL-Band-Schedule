<?php
// File: /band_list.php

require_once("includes/constants.php");
require_once("includes/connection.php");
require_once("includes/functions.php");


$cardView = 0;

if (isset($_GET['card']) && $_GET['card'] == 1) {
    $cardView = (int) $_GET['card'];
}


///////////////////////////////////////////////
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name         = trim($_POST['name'] ?? '');
    $city         = trim($_POST['city'] ?? '');
    $state        = trim($_POST['state'] ?? '');
    $contact_info = trim($_POST['contact_info'] ?? '');

    if (!empty($name)) {
        $stmt = mysqli_prepare($link, "
            INSERT INTO bands (name, city, state, contact_info)
            VALUES (?, ?, ?, ?)
        ");

        if ($stmt) {
            mysqli_stmt_bind_param($stmt, "ssss", $name, $city, $state, $contact_info);
            mysqli_stmt_execute($stmt);
            mysqli_stmt_close($stmt);
        }
    }

    header("Location: band_list.php");
    exit;
}
///////////////////////////////////////////////


// Sorting logic
$allowedSorts = ['name', 'city', 'state'];
$sort = $_GET['sort'] ?? 'name';
$dir = strtolower($_GET['dir'] ?? 'asc');

if (!in_array($sort, $allowedSorts)) {
    $sort = 'name';
}

if (!in_array($dir, ['asc', 'desc'])) {
    $dir = 'asc';
}

$nextDir = $dir === 'asc' ? 'desc' : 'asc';

$query = "SELECT id, name, city, state, contact_info FROM bands ORDER BY $sort $dir";
$result = mysqli_query($link, $query);

$bands = [];

while ($row = mysqli_fetch_assoc($result)) {
    $bands[] = $row;
}

$currentSort = $sort;
$currentDir = $dir;


$currNav = "Band List";
require_once("includes/header.php");
?>

<section>

    <div class="sub-header">
        <h1>Bands</h1>

        <button class="button btn-dark-grey medium has-icon" data-toggle-form="toggleForm">
            <i class="fas fa-plus"></i>
            <span>Add Band</span>
        </button>
    </div>


    <form method="POST" action="band_list.php" id="toggleForm" class="toggle-form">

        <div class="field">
            <label class="label">Band Name</label>
            <div class="control">
                <input class="input" type="text" name="name" required>
            </div>
        </div>

        <div class="columns">
            <div class="column">
                <div class="field">
                    <label class="label">City</label>
                    <div class="control">
                        <input class="input" type="text" name="city">
                    </div>
                </div>
            </div>

            <div class="column">
                <div class="field">
                    <label class="label">State</label>
                    <div class="control">
                        <input class="input" type="text" name="state">
                    </div>
                </div>
            </div>
        </div>

        <div class="field">
            <label class="label">Contact Info</label>
            <div class="control">
                <input class="input" type="text" name="contact_info">
            </div>
        </div>

        <div class="field is-grouped">
            <div class="control">
                <button type="submit" class="button btn-primary">Add Band</button>
            </div>
            <div class="control">
                <button class="button btn-grey" type="button" data-cancel-form="toggleForm">Cancel</button>
            </div>
        </div>
    </form>


    <?php if ($cardView === 1) { ?>

        <div class="sort-controls">
            <strong>Sort by:</strong>
            <a href="?sort=name&dir=<?php echo toggleDir($dir, $sort, 'name'); ?>">Name <i class="fas <?php echo sortIcon('name', $sort, $dir); ?>"></i></a>
            <a href="?sort=city&dir=<?php echo toggleDir($dir, $sort, 'city'); ?>">City <i class="fas <?php echo sortIcon('city', $sort, $dir); ?>"></i></a>
            <a href="?sort=state&dir=<?php echo toggleDir($dir, $sort, 'state'); ?>">State <i class="fas <?php echo sortIcon('state', $sort, $dir); ?>"></i></a>
        </div>

        <div class="info-card-grid">
            <?php foreach ($bands as $b): ?>
                <div class="info-card">
                    <h3><?php echo htmlspecialchars($b['name']); ?></h3>
                    <div class="details">
                        <div class="detail-row">
                            <span class="label">City:</span>
                            <span class="value"><strong><?php echo htmlspecialchars($b['city'] ?? ''); ?></strong></span>
                        </div>
                        <div class="detail-row">
                            <span class="label">State:</span>
                            <span class="value"><strong><?php echo htmlspecialchars($b['state'] ?? ''); ?></strong></span>
                        </div>
                        <div class="detail-row">
                            <span class="label">Contact:</span>
                            <span class="value"><strong><?php echo htmlspecialchars($b['contact_info'] ?? ''); ?></strong></span>
                        </div>
                    </div>
                    <div class="actions">
                        <a href="edit_band.php?id=<?php echo $b['id']; ?>" class="button btn-accent small">Edit</a>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>

    <?php } else { ?>

        <div class="table-wrapper">
            <table class="table is-striped is-fullwidth">
                <thead>
                    <tr>
                        <th>
                            <a href="?sort=name&dir=<?php echo toggleDir($dir); ?>">
                                Name <i class="fas <?php echo sortIcon('name', $sort, $dir); ?>"></i>
                            </a>
                        </th>
                        <th>
                            <a href="?sort=city&dir=<?php echo toggleDir($dir); ?>">
                                City <i class="fas <?php echo sortIcon('city', $sort, $dir); ?>"></i>
                            </a>
                        </th>
                        <th>
                            <a href="?sort=state&dir=<?php echo toggleDir($dir); ?>">
                                State <i class="fas <?php echo sortIcon('state', $sort, $dir); ?>"></i>
                            </a>
                        </th>
                        <th>Contact Info</th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (count($bands) === 0): ?>
                        <tr>
                            <td colspan="5"><em>No bands found.</em></td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($bands as $b): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($b['name']); ?></td>
                                <td><?php echo htmlspecialchars($b['city'] ?? ''); ?></td>
                                <td><?php echo htmlspecialchars($b['state'] ?? ''); ?></td>
                                <td><?php echo htmlspecialchars($b['contact_info'] ?? ''); ?></td>
                                <td>
                                    <a href="edit_band.php?id=<?php echo $b['id']; ?>" class="button btn-accent small">Edit</a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

    <?php } ?>

</section>

<?php
require_once("includes/footer.php");
