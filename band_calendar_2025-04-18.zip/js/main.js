document.addEventListener('DOMContentLoaded', () => {

  // ------------------ CALENDAR SETUP ------------------ //

  const calendarPopup = document.createElement('div');
  calendarPopup.id = 'calendarPopup';
  calendarPopup.className = 'calendar-popup';
  calendarPopup.style.display = 'none';
  calendarPopup.innerHTML = `
    <a href="#" class="popup-link"><i class="fas fa-plus"></i> New Show</a>
    <a href="#" class="popup-link"><i class="fas fa-ban"></i> Block Date</a>
  `;
  document.body.appendChild(calendarPopup);

  const prevBtn = document.getElementById('prevCustom');
  const nextBtn = document.getElementById('nextCustom');
  const titleDiv = document.getElementById('customCalendarTitle');
  const gridDiv = document.querySelector('#custom-calendar .calendar-grid');

  let currentDate = new Date();
  let showsByDate = {};
  let unavailableByDate = {};

  function fetchCalendarData(callback) {
    fetch('ajax/fetch_shows.php')
      .then(r => r.json())
      .then(data => {
        showsByDate = {};
        unavailableByDate = data.unavailable || {};
        (data.shows || []).forEach(show => {
          showsByDate[show.date] = showsByDate[show.date] || [];
          showsByDate[show.date].push(show);
        });
        callback();
      })
      .catch(err => {
        console.error('Calendar data load failed:', err);
        callback();
      });
  }

  function renderCalendar(date) {
    const year = date.getFullYear();
    const month = date.getMonth();
    const daysInMonth = new Date(year, month + 1, 0).getDate();
    const firstDay = new Date(year, month, 1).getDay();

    titleDiv.textContent = `${date.toLocaleDateString('en-US', { month: 'long' })} ${year}`;
    gridDiv.innerHTML = '';

    for (let i = 0; i < firstDay; i++) {
      const blank = document.createElement('div');
      blank.className = 'calendar-day blank';
      gridDiv.appendChild(blank);
    }

    for (let day = 1; day <= daysInMonth; day++) {
      const cell = document.createElement('div');
      cell.className = 'calendar-day';

      const dt = new Date(year, month, day);
      const dateStr = dt.toISOString().split('T')[0];
      const shows = showsByDate[dateStr] || [];
      const unavail = unavailableByDate[dateStr] || [];

      let statusClass = 'available';
      if (unavail.length > 0) statusClass = 'blocked';
      else if (shows.length > 0)
        statusClass = shows.some(show => show.confirmed == 0) ? 'unconfirmed-show' : 'has-show';

      cell.classList.add(statusClass);
      if (dt.toDateString() === new Date().toDateString()) {
        cell.classList.add('today');
      }

      const dot = document.createElement('span');
      dot.className = 'day-number';
      dot.textContent = day;
      cell.appendChild(dot);

      if (unavail.length > 0 || shows.length > 0) {
        const link = document.createElement('a');
        link.href = unavail.length > 0
          ? `block_time.php#${dateStr}`
          : `edit_show.php?id=${shows[0].id}`;
        link.style.cssText = 'display:block;width:100%;height:100%;text-decoration:none;color:inherit;';
        while (cell.firstChild) link.appendChild(cell.firstChild);
        cell.appendChild(link);
      } else {
        cell.addEventListener('click', (e) => {
          e.stopPropagation();
          showCalendarPopup(e, dateStr);
        });
      }

      gridDiv.appendChild(cell);
    }
  }

  function showCalendarPopup(e, dateStr) {
    const popup = calendarPopup;
    popup.querySelectorAll('a')[0].href = `new_show.php?date=${dateStr}`;
    popup.querySelectorAll('a')[1].href = `block_time.php?date=${dateStr}`;

    const rect = e.currentTarget.getBoundingClientRect();
    const top = rect.top + window.scrollY + rect.height;
    let left = rect.left;

    popup.style.left = `${left}px`;
    popup.style.top = `${top}px`;
    popup.style.display = 'block';

    setTimeout(() => {
      const overflow = left + popup.offsetWidth > window.innerWidth;
      popup.style.left = overflow ? `${left - popup.offsetWidth + rect.width}px` : `${left}px`;
      popup.classList.toggle('flipped-left', overflow);
    }, 0);
  }

  prevBtn?.addEventListener('click', () => {
    currentDate.setMonth(currentDate.getMonth() - 1);
    renderCalendar(currentDate);
  });

  nextBtn?.addEventListener('click', () => {
    currentDate.setMonth(currentDate.getMonth() + 1);
    renderCalendar(currentDate);
  });

  document.addEventListener('click', (e) => {
    if (!e.target.closest('#calendarPopup')) {
      calendarPopup.style.display = 'none';
    }
  });

  fetchCalendarData(() => renderCalendar(currentDate));

  // ------------------ SWIPE FOR CALENDAR ------------------ //

  const calendarEl = document.getElementById('custom-calendar');
  const calendarGrid = calendarEl?.querySelector('.calendar-grid');
  let startX = 0;
  let isTouch = false;

  function animateSwipe(direction) {
    if (!calendarGrid) return;
    calendarGrid.classList.add(`swipe-${direction}`);
    setTimeout(() => calendarGrid.classList.remove(`swipe-${direction}`), 300);
  }

  calendarEl?.addEventListener('touchstart', e => {
    isTouch = true;
    startX = e.changedTouches[0].screenX;
  });

  calendarEl?.addEventListener('touchend', e => {
    const delta = e.changedTouches[0].screenX - startX;
    if (Math.abs(delta) >= 50) {
      animateSwipe(delta < 0 ? 'left' : 'right');
      (delta < 0 ? nextBtn : prevBtn)?.click();
    }
  });

  calendarEl?.addEventListener('mousedown', e => {
    isTouch = false;
    startX = e.screenX;
  });

  calendarEl?.addEventListener('mouseup', e => {
    if (!isTouch) {
      const delta = e.screenX - startX;
      if (Math.abs(delta) >= 50) {
        animateSwipe(delta < 0 ? 'left' : 'right');
        (delta < 0 ? nextBtn : prevBtn)?.click();
      }
    }
  });

  // ------------------ TOGGLE FORM ------------------ //

  const toggleBtn = document.querySelector('[data-toggle-form]');
  const cancelBtn = document.querySelector('[data-cancel-form]');
  const form = document.getElementById('toggleForm');

  toggleBtn?.addEventListener('click', () => form?.classList.toggle('is-expanded'));
  cancelBtn?.addEventListener('click', () => form?.classList.remove('is-expanded'));

  // ------------------ SORTABLE BANDS ------------------ //

  const bandList = document.getElementById('assignedBandsUL');
  if (bandList && window.showID) {
    new Sortable(bandList, {
      animation: 150,
      onEnd: () => {
        const order = [...bandList.children].map(li => li.dataset.id);
        fetch('ajax/update_band_order.php', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ show_id: window.showID, band_ids: order })
        })
          .then(r => r.json())
          .then(data => {
            if (!data.success) alert('Failed to save new order.');
          })
          .catch(err => console.error('Order update failed:', err));
      }
    });
  }

  // ------------------ AUTOCOMPLETE SETUP ------------------ //

  function setupAutocomplete(inputId, apiUrl, hiddenId, callback = null) {
    const input = document.getElementById(inputId);
    const hidden = document.getElementById(hiddenId);
    if (!input || !hidden) return;

    const suggBox = document.createElement('div');
    suggBox.className = 'autocomplete-suggestions';
    input.parentNode.style.position = 'relative';
    input.parentNode.appendChild(suggBox);

    let debounceTimer, activeIndex = -1;

    function closeSuggestions() {
      suggBox.innerHTML = '';
      suggBox.style.display = 'none';
      activeIndex = -1;
    }

    input.addEventListener('input', () => {
      const q = input.value.trim();
      hidden.value = '';
      if (!q) return closeSuggestions();
      clearTimeout(debounceTimer);
      debounceTimer = setTimeout(() => {
        fetch(`${apiUrl}?term=${encodeURIComponent(q)}`)
          .then(r => r.json())
          .then(results => {
            suggBox.innerHTML = '';
            if (!results.length) {
              const div = document.createElement('div');
              div.className = 'autocomplete-suggestion is-add-new';
              div.innerHTML = `<span class="plus-icon"><i class="fas fa-plus"></i></span> Add New '<strong>${q}</strong>'`;
              div.dataset.name = q;
              div.addEventListener('mousedown', () => {
                closeSuggestions();
                if (inputId === 'venueSearch') {
                  fetch(`ajax/add_new_venue.php?name=${encodeURIComponent(q)}`)
                    .then(r => r.json())
                    .then(data => {
                      if (data.success) {
                        hidden.value = data.venue_id;
                        input.value = '';
                        input.blur();
                        const venueDisplay = document.getElementById('venueDisplay');
                        if (venueDisplay) venueDisplay.textContent = data.name;
                      } else alert(data.error || 'Failed to create venue.');
                    })
                    .catch(err => alert('Error creating venue.'));
                } else if (callback) {
                  callback({ name: q, isNew: true });
                }
              });
              suggBox.appendChild(div);
              suggBox.style.display = 'block';
              return;
            }

            results.forEach((item, index) => {
              const div = document.createElement('div');
              div.className = 'autocomplete-suggestion';
              div.textContent = item.name;
              div.dataset.id = item.id;
              div.dataset.name = item.name;
              div.addEventListener('mousedown', () => {
                input.value = item.name;
                hidden.value = item.id;
                closeSuggestions();
                if (callback) callback(item);
              });
              suggBox.appendChild(div);
            });
            suggBox.style.display = 'block';
          })
          .catch(() => closeSuggestions());
      }, 300);
    });

    input.addEventListener('keydown', (e) => {
      const items = suggBox.querySelectorAll('.autocomplete-suggestion');
      if (!items.length) return;

      if (e.key === 'ArrowDown') activeIndex = (activeIndex + 1) % items.length;
      else if (e.key === 'ArrowUp') activeIndex = (activeIndex - 1 + items.length) % items.length;
      else if (e.key === 'Enter' && activeIndex >= 0) {
        e.preventDefault();
        items[activeIndex].dispatchEvent(new Event('mousedown'));
      }

      items.forEach((el, i) => el.classList.toggle('is-active', i === activeIndex));
    });

    input.addEventListener('blur', () => setTimeout(closeSuggestions, 200));
    document.addEventListener('click', (e) => {
      if (!suggBox.contains(e.target) && e.target !== input) closeSuggestions();
    });
  }

  setupAutocomplete('venueSearch', 'ajax/autocomplete_venues.php', 'venue_id', (item) => {
    const venueInput = document.getElementById('venueSearch');
    const venueDisplay = document.getElementById('venueDisplay');
    if (venueDisplay) venueDisplay.textContent = item.name;
    if (venueInput) {
      venueInput.value = '';
      venueInput.blur();
    }
    if (window.showID && item.id) {
      fetch('ajax/update_show_venue.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: `show_id=${window.showID}&venue_id=${item.id}`
      }).catch(console.error);
    }
  });

  setupAutocomplete('bandSearch', 'ajax/autocomplete_bands.php', 'band_id', (item) => {
    if (!window.showID) return;
    const ul = document.getElementById('assignedBandsUL');
    const assignBand = (id, name) => {
      fetch(`ajax/add_band_list.php?show_id=${window.showID}&band_id=${id}`)
        .then(r => r.json())
        .then(data => {
          if (!data.success) return alert(data.error || 'Failed to add band.');
          const placeholder = ul.querySelector('li em');
          if (placeholder) placeholder.closest('li')?.remove();
          const li = document.createElement('li');
          li.dataset.id = id;
          li.innerHTML = `
            <span class="drag-handle">☰</span>
            <span class="band-name">${item.name}</span>
            <a href="edit_show.php?del=1&id=${window.showID}&show_id=${window.showID}&band_id=${item.id}" class="delete-icon">
              <i class="fas fa-times"></i>
            </a>`;
          ul.appendChild(li);
          const bandInput = document.getElementById('bandSearch');
          bandInput.value = '';
          bandInput.blur();
        });
    };

    if (item.isNew) {
      fetch(`ajax/add_new_band.php?name=${encodeURIComponent(item.name)}`)
        .then(r => r.json())
        .then(newBand => {
          if (newBand.success) assignBand(newBand.band_id, newBand.name);
          else alert(newBand.error || 'Failed to create band.');
        });
    } else {
      assignBand(item.id, item.name);
    }
  });
});
