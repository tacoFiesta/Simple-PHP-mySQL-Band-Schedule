<?php
require_once("includes/constants.php");
require_once("includes/connection.php");
require_once("includes/functions.php");

$admin = 0;

if (isset($_GET['admin']) && $_GET['admin'] == 1) {
    $admin = (int) $_GET['admin'];
}

if (!isset($_GET['id'])) {
    die("No show ID provided.");
}

$show_id = (int) $_GET['id'];

if ($show_id < 1) {
    die("Invalid show ID.");
}

////////////////////////////////////////////////
// Remove band from show
if (isset($_GET['del']) && $_GET['del'] == 1) {
    $show_id = (int) ($_GET['show_id'] ?? 0);
    $band_id = (int) ($_GET['band_id'] ?? 0);

    if ($show_id > 0 && $band_id > 0) {
        $stmt = mysqli_prepare($link, "
            DELETE FROM show_bands
            WHERE show_id = ? AND band_id = ?
            LIMIT 1
        ");

        if ($stmt) {
            mysqli_stmt_bind_param($stmt, "ii", $show_id, $band_id);
            mysqli_stmt_execute($stmt);
            mysqli_stmt_close($stmt);
        }
    }

    header("Location: edit_show.php?id=$show_id");
    exit;
}

////////////////////////////////////////////////
// Handle show update or deletion
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $show_id = (int) ($_POST['id'] ?? 0);

    if (isset($_POST['delete']) && $_POST['delete'] == 1 && $show_id > 0) {
        $stmt1 = mysqli_prepare($link, "DELETE FROM show_bands WHERE show_id = ?");
        if ($stmt1) {
            mysqli_stmt_bind_param($stmt1, "i", $show_id);
            mysqli_stmt_execute($stmt1);
            mysqli_stmt_close($stmt1);
        }

        $stmt2 = mysqli_prepare($link, "DELETE FROM shows WHERE id = ? LIMIT 1");
        if ($stmt2) {
            mysqli_stmt_bind_param($stmt2, "i", $show_id);
            mysqli_stmt_execute($stmt2);
            mysqli_stmt_close($stmt2);
        }

        header("Location: index.php");
        exit;
    }

    if (isset($_POST['update']) && $_POST['update'] == 1 && $show_id > 0) {
        $show_date = trim($_POST['show_date'] ?? '');
        $show_time = trim($_POST['show_time'] ?? '');
        $confirmed = (int) ($_POST['confirmed'] ?? 0);

        $stmt = mysqli_prepare($link, "
            UPDATE shows
            SET show_date = ?, show_time = ?, confirmed = ?
            WHERE id = ?
            LIMIT 1
        ");

        if ($stmt) {
            mysqli_stmt_bind_param($stmt, "ssii", $show_date, $show_time, $confirmed, $show_id);
            mysqli_stmt_execute($stmt);
            mysqli_stmt_close($stmt);
        }

        header("Location: edit_show.php?id=$show_id");
        exit;
    }
}

////////////////////////////////////////////////
// Fetch show details
$stmt = mysqli_prepare($link, "
    SELECT shows.id, shows.show_date, shows.show_time, shows.confirmed,
           venues.id AS venue_id, venues.name AS venue_name
    FROM shows
    LEFT JOIN venues ON shows.venue_id = venues.id
    WHERE shows.id = ?
    LIMIT 1
");

mysqli_stmt_bind_param($stmt, "i", $show_id);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);
$showData = mysqli_fetch_assoc($result);
mysqli_stmt_close($stmt);

if (!$showData) {
    die("No show found.");
}

$currVenueName = $showData['venue_name'] ?? 'No Venue';

////////////////////////////////////////////////
// Fetch current bands
$assignedBands = [];

$stmtBands = mysqli_prepare($link, "
    SELECT show_bands.band_id, bands.name
    FROM show_bands
    LEFT JOIN bands ON show_bands.band_id = bands.id
    WHERE show_bands.show_id = ?
    ORDER BY show_bands.slot_order
");

mysqli_stmt_bind_param($stmtBands, "i", $show_id);
mysqli_stmt_execute($stmtBands);
$resBands = mysqli_stmt_get_result($stmtBands);

while ($row = mysqli_fetch_assoc($resBands)) {
    $assignedBands[] = ['id' => $row['band_id'], 'name' => $row['name']];
}

mysqli_stmt_close($stmtBands);

$currNav = "Edit a Show Form";
require_once("includes/header.php");
?>

<section>

    <div class="sub-header">
        <h1>Edit Show</h1>
    </div>

    <form method="POST" action="edit_show.php?id=<?= $showData['id']; ?>">
        <input type="hidden" name="id" value="<?= $showData['id']; ?>">

        <div class="columns">
            <div class="column is-half">
                <label class="label">Show Date</label>
                <input class="input" type="date" name="show_date" value="<?= htmlspecialchars($showData['show_date']); ?>">
            </div>

            <div class="column is-half">
                <label class="label">Show Time</label>
                <input class="input" type="time" name="show_time" value="<?= htmlspecialchars($showData['show_time']); ?>">
            </div>
        </div>

        <label class="label" style="margin-top: 1rem;">Confirmed?</label>
        <div class="select">
            <select name="confirmed">
                <option value="0" <?= $showData['confirmed'] == 0 ? 'selected' : ''; ?>>No</option>
                <option value="1" <?= $showData['confirmed'] == 1 ? 'selected' : ''; ?>>Yes</option>
            </select>
        </div>

        <div class="field is-grouped">
            <div class="control">
                <button type="submit" class="button btn-primary">Save Changes</button>
                <input type="hidden" name="update" value="1">
            </div>
            <div class="control">
                <a href="index.php" class="button btn-grey">Cancel</a>
            </div>
        </div>
    </form>

    <form>
        <div class="field">
            <label class="label">Venue</label>
            <div id="venueDisplay" class="venue-display">
                <?= htmlspecialchars($currVenueName); ?>
            </div>
        </div>

        <div style="position: relative;">
            <input id="venueSearch" class="input" type="text" placeholder="Type venue name...">
            <input id="venue_id" type="hidden" name="venue_id" value="<?= htmlspecialchars($showData['venue_id']); ?>">
            <div id="venueSuggestions" class="autocomplete-suggestions" style="display: none;"></div>
        </div>

        <script>
            window.showID = <?= (int) $showData['id']; ?>;
        </script>

        <label class="label" style="margin-top: 1.5rem;">Band List</label>
        <ul class="band-list" id="assignedBandsUL">
            <?php if ($assignedBands): ?>
                <?php foreach ($assignedBands as $b): ?>
                    <li data-id="<?= $b['id'] ?>">
                        <span class="drag-handle">☰</span>
                        <span class="band-name"><?= htmlspecialchars($b['name']) ?></span>
                        <a href="edit_show.php?del=1&show_id=<?= $show_id ?>&band_id=<?= $b['id'] ?>&id=<?= $b['id'] ?>" class="delete-icon">
                            <i class="fas fa-times"></i>
                        </a>
                    </li>
                <?php endforeach; ?>
            <?php else: ?>
                <li><em>---</em></li>
            <?php endif; ?>
        </ul>

        <label class="label" style="margin-top: 1.5rem;">Add a Band</label>
        <div style="position: relative;">
            <input id="bandSearch" class="input" type="text" placeholder="Type band name...">
            <input id="band_id" type="hidden">
            <div id="suggestions" class="autocomplete-suggestions" style="display:none;"></div>
        </div>
    </form>

    <?php if ($admin == 1): ?>
        <form method="POST" action="edit_show.php?id=<?= $show_id; ?>" style="float: right;">
            <input type="hidden" name="id" value="<?= $show_id; ?>">
            <input type="hidden" name="delete" value="1">
            <button class="button is-danger is-small has-icon" onclick="return confirm('Are you sure you want to delete this show?');">
                <i class="fas fa-trash"></i> Delete Show
            </button>
        </form>
    <?php endif; ?>

</section>

<script>
    window.showID = <?= (int) $show_id ?>;
</script>

<?php require_once("includes/footer.php"); ?>
