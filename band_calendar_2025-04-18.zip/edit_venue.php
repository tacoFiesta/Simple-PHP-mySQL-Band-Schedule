<?php
// File: /edit_venue.php
require_once("includes/constants.php");
require_once("includes/connection.php");
require_once("includes/functions.php");

$venue_id = (int) ($_GET['id'] ?? 0);

if ($venue_id < 1) {
    die("Invalid venue ID.");
}

////////////////////////////////////////////////
// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $venue_id  = (int) ($_POST['id'] ?? 0);
    $name      = trim($_POST['name'] ?? '');
    $address   = trim($_POST['address'] ?? '');
    $city      = trim($_POST['city'] ?? '');
    $state     = trim($_POST['state'] ?? '');
    $zip_code  = trim($_POST['zip_code'] ?? '');

    if ($venue_id < 1 || $name === '') {
        header("Location: venue_list.php");
        exit;
    }

    $stmt = mysqli_prepare($link, "
        UPDATE venues
        SET name = ?, address = ?, city = ?, state = ?, zip_code = ?
        WHERE id = ?
        LIMIT 1
    ");

    if ($stmt) {
        mysqli_stmt_bind_param($stmt, "sssssi", $name, $address, $city, $state, $zip_code, $venue_id);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_close($stmt);
    }

    header("Location: venue_list.php");
    exit;
}

////////////////////////////////////////////////
// Fetch venue from DB
$stmt = mysqli_prepare($link, "
    SELECT id, name, address, city, state, zip_code
    FROM venues
    WHERE id = ?
    LIMIT 1
");

if (!$stmt) {
    die("Failed to prepare statement.");
}

mysqli_stmt_bind_param($stmt, "i", $venue_id);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);
$venueData = mysqli_fetch_assoc($result);
mysqli_stmt_close($stmt);

if (!$venueData) {
    header("Location: venue_list.php");
    exit;
}

$currNav = "Edit Venue";
require_once("includes/header.php");
?>

<section>

    <div class="sub-header">
        <h1>Edit Venue</h1>
    </div>

    <form method="POST" action="edit_venue.php?id=<?php echo $venueData['id']; ?>">
        <input type="hidden" name="id" value="<?php echo $venueData['id']; ?>">

        <div class="field">
            <label class="label">Name</label>
            <div class="control">
                <input class="input" type="text" name="name"
                    value="<?php echo htmlspecialchars($venueData['name'] ?? ''); ?>"
                    required>
            </div>
        </div>

        <div class="field">
            <label class="label">Address</label>
            <div class="control">
                <input class="input" type="text" name="address"
                    value="<?php echo htmlspecialchars($venueData['address'] ?? ''); ?>">
            </div>
        </div>

        <div class="columns">

            <div class="column">
                <div class="field">
                    <label class="label">City</label>
                    <div class="control">
                        <input class="input" type="text" name="city"
                            value="<?php echo htmlspecialchars($venueData['city'] ?? ''); ?>">
                    </div>
                </div>
            </div>

            <div class="column">
                <div class="field">
                    <label class="label">State</label>
                    <div class="control">
                        <input class="input" type="text" name="state"
                            value="<?php echo htmlspecialchars($venueData['state'] ?? ''); ?>">
                    </div>
                </div>
            </div>

            <div class="column">
                <div class="field">
                    <label class="label">Zip Code</label>
                    <div class="control">
                        <input class="input" type="text" name="zip_code"
                            value="<?php echo htmlspecialchars($venueData['zip_code'] ?? ''); ?>">
                    </div>
                </div>
            </div>

        </div>

        <div class="field is-grouped mt-4">
            <div class="control">
                <button type="submit" class="button btn-primary">Save</button>
            </div>
            <div class="control">
                <a href="venue_list.php" class="button is-light">Cancel</a>
            </div>
        </div>
    </form>

</section>

<?php
require_once("includes/footer.php");
