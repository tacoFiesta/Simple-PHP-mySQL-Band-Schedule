<?php
// File: add_new_band.php
require_once("../includes/constants.php");
require_once("../includes/connection.php");
require_once("../includes/functions.php");
header("Content-Type: application/json");

$name = trim($_GET['name'] ?? '');

if ($name === '') {
  echo json_encode(['success' => false, 'error' => 'No band name provided.']);
  exit;
}

// Check for duplicates (case-insensitive)
$existing_id = null;
$stmt = mysqli_prepare($link, "SELECT id FROM bands WHERE LOWER(name) = LOWER(?) LIMIT 1");
if ($stmt) {
  mysqli_stmt_bind_param($stmt, "s", $name);
  mysqli_stmt_execute($stmt);
  $result = mysqli_stmt_get_result($stmt);
  if ($row = mysqli_fetch_assoc($result)) {
    $existing_id = $row['id'];
  }
  mysqli_stmt_close($stmt);
}

if ($existing_id) {
  echo json_encode(['success' => true, 'band_id' => $existing_id, 'name' => $name]);
  exit;
}

// Insert new band
$stmt = mysqli_prepare($link, "INSERT INTO bands (name) VALUES (?)");
if ($stmt) {
  mysqli_stmt_bind_param($stmt, "s", $name);
  $success = mysqli_stmt_execute($stmt);
  $new_id = mysqli_insert_id($link);
  mysqli_stmt_close($stmt);

  if ($success) {
    echo json_encode(['success' => true, 'band_id' => $new_id, 'name' => $name]);
  } else {
    echo json_encode(['success' => false, 'error' => 'Failed to create new band.']);
  }
} else {
  echo json_encode(['success' => false, 'error' => 'Failed to prepare insert statement.']);
}
