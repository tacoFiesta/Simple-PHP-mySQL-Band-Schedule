<?php
// File: ajax/add_new_venue.php
require_once("../includes/constants.php");
require_once("../includes/connection.php");
require_once("../includes/functions.php");
header("Content-Type: application/json");

$name = trim($_GET['name'] ?? '');

if (strlen($name) < 2) {
  echo json_encode(['error' => 'Venue name too short.']);
  exit;
}

// Normalize input for comparison (remove apostrophes, lowercase)
$normalizedInput = strtolower(str_replace("'", '', $name));

// Check if venue already exists (apostrophe-insensitive, case-insensitive)
$venue_id = null;
$venue_name = null;

$checkQuery = "SELECT id, name FROM venues";
$checkResult = mysqli_query($link, $checkQuery);

while ($row = mysqli_fetch_assoc($checkResult)) {
  $normalizedRow = strtolower(str_replace("'", '', $row['name']));
  if ($normalizedRow === $normalizedInput) {
    $venue_id = $row['id'];
    $venue_name = $row['name'];
    break;
  }
}

if ($venue_id) {
  echo json_encode(['success' => true, 'venue_id' => $venue_id, 'name' => $venue_name]);
  exit;
}

// Insert new venue using prepared statement
$stmt = mysqli_prepare($link, "INSERT INTO venues (name) VALUES (?)");
if ($stmt) {
  mysqli_stmt_bind_param($stmt, "s", $name);
  $success = mysqli_stmt_execute($stmt);
  $new_id = mysqli_insert_id($link);
  mysqli_stmt_close($stmt);

  if ($success) {
    echo json_encode(['success' => true, 'venue_id' => $new_id, 'name' => $name]);
  } else {
    echo json_encode(['error' => 'Database insert failed.']);
  }
} else {
  echo json_encode(['error' => 'Failed to prepare insert statement.']);
}
