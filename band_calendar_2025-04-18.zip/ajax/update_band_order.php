<?php
require_once("../includes/constants.php");
require_once("../includes/connection.php");
require_once("../includes/functions.php");
header("Content-Type: application/json");

// Decode JSON input
$data = json_decode(file_get_contents("php://input"), true);
$show_id = (int)($data['show_id'] ?? 0);
$band_ids = $data['band_ids'] ?? [];

if ($show_id < 1 || !is_array($band_ids)) {
  echo json_encode(['success' => false, 'error' => 'Invalid input']);
  exit;
}

// Prepare the statement once
$stmt = mysqli_prepare($link, "
  UPDATE show_bands 
  SET slot_order = ? 
  WHERE show_id = ? AND band_id = ?
");

if (!$stmt) {
  echo json_encode(['success' => false, 'error' => 'DB prepare failed']);
  exit;
}

// Execute update for each band_id with correct slot_order
foreach ($band_ids as $order => $band_id) {
  $band_id = (int)$band_id;
  $slot_order = (int)$order + 1;
  mysqli_stmt_bind_param($stmt, "iii", $slot_order, $show_id, $band_id);
  mysqli_stmt_execute($stmt);
}

mysqli_stmt_close($stmt);

echo json_encode(['success' => true]);
exit;
