<?php
require_once("../includes/constants.php");
require_once("../includes/connection.php");
require_once("../includes/functions.php");

$show_id = (int)($_GET['show_id'] ?? 0);
$band_id = (int)($_GET['band_id'] ?? 0);

// Validate IDs before executing query
if ($show_id > 0 && $band_id > 0) {
    $stmt = mysqli_prepare($link, "
        DELETE FROM show_bands
        WHERE show_id = ? AND band_id = ?
        LIMIT 1
    ");

    if ($stmt) {
        mysqli_stmt_bind_param($stmt, "ii", $show_id, $band_id);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_close($stmt);
    }
}

// Redirect back to edit page
header("Location: edit_show.php?id=$show_id");
exit;
