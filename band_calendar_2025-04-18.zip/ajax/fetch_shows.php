<?php
require_once("../includes/constants.php");
require_once("../includes/connection.php");
require_once("../includes/functions.php");
header("Content-Type: application/json");

// Ensure DB connection
if (!$link) {
  echo json_encode(["error" => "Database connection failed."]);
  exit;
}

// Optional: set charset
// mysqli_set_charset($link, "utf8mb4");

// 1) Fetch Shows
$shows = [];
$shows_sql = "
  SELECT
    s.id AS show_id,
    s.show_date,
    s.show_time,
    s.confirmed,
    v.name AS venue,
    GROUP_CONCAT(b.name ORDER BY sb.slot_order SEPARATOR ', ') AS bands
  FROM shows s
  LEFT JOIN venues v ON s.venue_id = v.id
  LEFT JOIN show_bands sb ON s.id = sb.show_id
  LEFT JOIN bands b ON sb.band_id = b.id
  GROUP BY s.id
  ORDER BY s.show_date ASC
";

if ($stmt = mysqli_prepare($link, $shows_sql)) {
  mysqli_stmt_execute($stmt);
  $result = mysqli_stmt_get_result($stmt);
  while ($row = mysqli_fetch_assoc($result)) {
    $shows[] = [
      'id'        => $row['show_id'],
      'date'      => $row['show_date'],
      'time'      => $row['show_time'],
      'confirmed' => $row['confirmed'],
      'venue'     => $row['venue'],
      'bands'     => $row['bands']
    ];
  }
  mysqli_stmt_close($stmt);
}

// 2) Fetch Unavailable Members
$unavailable = [];
$unavail_sql = "
  SELECT 
    bmu.unavailable_date AS date,
    bm.name AS member,
    bmu.reason
  FROM band_member_unavailability bmu
  LEFT JOIN band_members bm ON bmu.member_id = bm.id
  ORDER BY bmu.unavailable_date ASC
";

if ($stmt = mysqli_prepare($link, $unavail_sql)) {
  mysqli_stmt_execute($stmt);
  $result = mysqli_stmt_get_result($stmt);
  while ($row = mysqli_fetch_assoc($result)) {
    $unavailable[$row['date']][] = [
      'member' => $row['member'],
      'reason' => $row['reason']
    ];
  }
  mysqli_stmt_close($stmt);
}

// 3) Output JSON
$response = json_encode([
  'shows' => $shows,
  'unavailable' => $unavailable
], JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE);

if ($response === false) {
  echo json_encode([
    'error' => 'json_encode failed',
    'reason' => json_last_error_msg(),
    'showsCount' => count($shows),
    'unavailCount' => count($unavailable)
  ]);
  exit;
}

echo $response;
exit;
