<?php
// File: ajax/update_show_venue.php
require_once("../includes/constants.php");
require_once("../includes/connection.php");
require_once("../includes/functions.php");
header("Content-Type: application/json");

$show_id = (int)($_POST['show_id'] ?? 0);
$venue_id = (int)($_POST['venue_id'] ?? 0);

if ($show_id < 1 || $venue_id < 1) {
    echo json_encode(['success' => false, 'error' => 'Invalid show or venue ID.']);
    exit;
}

$stmt = mysqli_prepare($link, "UPDATE shows SET venue_id = ? WHERE id = ? LIMIT 1");

if (!$stmt) {
    echo json_encode(['success' => false, 'error' => 'Database prepare failed.']);
    exit;
}

mysqli_stmt_bind_param($stmt, "ii", $venue_id, $show_id);
$success = mysqli_stmt_execute($stmt);
mysqli_stmt_close($stmt);

if ($success) {
    echo json_encode(['success' => true]);
} else {
    echo json_encode(['success' => false, 'error' => 'Database update failed.']);
}
