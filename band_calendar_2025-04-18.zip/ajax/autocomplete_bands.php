<?php
// File: ajax/autocomplete_bands.php
require_once("../includes/constants.php");
require_once("../includes/connection.php");
require_once("../includes/functions.php");
header("Content-Type: application/json");

$term = trim($_GET['term'] ?? '');

if (strlen($term) < 1) {
  echo json_encode([]);
  exit;
}

// Normalize input: lowercase and remove apostrophes
$normalizedTerm = '%' . strtolower(str_replace("'", '', $term)) . '%';

// Build query for normalized search
$sql = "
  SELECT id, name
  FROM bands
  WHERE REPLACE(LOWER(name), \"'\", '') LIKE ?
  ORDER BY name
  LIMIT 10
";

$stmt = mysqli_prepare($link, $sql);
if ($stmt) {
  mysqli_stmt_bind_param($stmt, "s", $normalizedTerm);
  mysqli_stmt_execute($stmt);
  $result = mysqli_stmt_get_result($stmt);

  $matches = [];
  while ($row = mysqli_fetch_assoc($result)) {
    $matches[] = [
      'id'   => $row['id'],
      'name' => $row['name']
    ];
  }

  echo json_encode($matches);
  mysqli_stmt_close($stmt);
} else {
  echo json_encode([]);
}
