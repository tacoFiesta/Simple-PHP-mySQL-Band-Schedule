<?php
// File: add_band_list.php
require_once("../includes/constants.php");
require_once("../includes/connection.php");
require_once("../includes/functions.php");
header("Content-Type: application/json");

$show_id = (int)($_GET['show_id'] ?? 0);
$band_id = (int)($_GET['band_id'] ?? 0);

if ($show_id < 1 || $band_id < 1) {
  echo json_encode(['error' => 'Invalid show or band ID.']);
  exit;
}

// 1) Look up the band name
$bandRow = null;
$stmt = mysqli_prepare($link, "SELECT name FROM bands WHERE id = ? LIMIT 1");
if ($stmt) {
  mysqli_stmt_bind_param($stmt, "i", $band_id);
  mysqli_stmt_execute($stmt);
  $result = mysqli_stmt_get_result($stmt);
  $bandRow = mysqli_fetch_assoc($result);
  mysqli_stmt_close($stmt);
}

if (!$bandRow) {
  echo json_encode(['error' => 'Band not found.']);
  exit;
}

// 2) Find the highest slot_order for this show
$newSlot = 1;
$stmt = mysqli_prepare($link, "SELECT MAX(slot_order) AS maxSlot FROM show_bands WHERE show_id = ?");
if ($stmt) {
  mysqli_stmt_bind_param($stmt, "i", $show_id);
  mysqli_stmt_execute($stmt);
  $result = mysqli_stmt_get_result($stmt);
  $slotRow = mysqli_fetch_assoc($result);
  $newSlot = (int)($slotRow['maxSlot'] ?? 0) + 1;
  mysqli_stmt_close($stmt);
}

// 3) Insert into show_bands (use INSERT IGNORE to avoid duplicates)
$stmt = mysqli_prepare($link, "
  INSERT IGNORE INTO show_bands (show_id, band_id, slot_order)
  VALUES (?, ?, ?)
");
if ($stmt) {
  mysqli_stmt_bind_param($stmt, "iii", $show_id, $band_id, $newSlot);
  mysqli_stmt_execute($stmt);
  $affected = mysqli_stmt_affected_rows($stmt);
  mysqli_stmt_close($stmt);

  if ($affected > 0) {
    echo json_encode([
      'success' => true,
      'band_id' => $band_id,
      'name'    => $bandRow['name'],
      'slot_order' => $newSlot
    ]);
  } else {
    echo json_encode([
      'success' => false,
      'message' => 'Band may already be assigned to this show or an error occurred.'
    ]);
  }
} else {
  echo json_encode(['error' => 'Failed to prepare insert statement.']);
}
