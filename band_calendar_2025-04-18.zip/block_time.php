<?php
require_once("includes/constants.php");
require_once("includes/connection.php");
require_once("includes/functions.php");

$prefillDate = $_GET['date'] ?? '';


////////////////////////////////////////////////
if (isset($_GET['del']) && $_GET['del'] == 1) {
    $block_id = (int) ($_GET['id'] ?? 0);

    $stmt = mysqli_prepare($link, "DELETE FROM band_member_unavailability WHERE id = ? LIMIT 1");
    mysqli_stmt_bind_param($stmt, "i", $block_id);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);

    header("Location: block_time.php");
    exit;
}


////////////////////////////////////////////////
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $start  = mysqli_real_escape_string($link, $_POST['unavailable_date_start'] ?? '');
    $end    = mysqli_real_escape_string($link, $_POST['unavailable_date_end'] ?? '');
    $member = (int) ($_POST['member_id'] ?? 0);
    $reason = mysqli_real_escape_string($link, $_POST['reason'] ?? '');

    if ($start && $member) {
        $startDate = new DateTime($start);
        $endDate   = $end ? new DateTime($end) : clone $startDate;
        $period    = new DatePeriod($startDate, new DateInterval('P1D'), $endDate->modify('+1 day'));

        $stmt = mysqli_prepare($link, "
            INSERT INTO band_member_unavailability (member_id, unavailable_date, reason)
            VALUES (?, ?, ?)
        ");

        foreach ($period as $day) {
            $dateStr = $day->format('Y-m-d');
            mysqli_stmt_bind_param($stmt, "iss", $member, $dateStr, $reason);
            mysqli_stmt_execute($stmt);
        }

        mysqli_stmt_close($stmt);

        header("Location: block_time.php");
        exit;
    }
}


////////////////////////////////////////////////
// Fetch members

$members = [];
$member_q = mysqli_query($link, "SELECT id, name FROM band_members ORDER BY name");

while ($m = mysqli_fetch_assoc($member_q)) {
    $members[] = $m;
}


////////////////////////////////////////////////
// Fetch upcoming blocked dates

$blocks = [];
$today = date('Y-m-d');

$block_q = mysqli_query($link, "
    SELECT bmu.id, bmu.unavailable_date, bmu.reason, m.name AS member
    FROM band_member_unavailability bmu
    LEFT JOIN band_members m ON bmu.member_id = m.id
    WHERE bmu.unavailable_date >= '$today'
    ORDER BY bmu.unavailable_date ASC
");

while ($b = mysqli_fetch_assoc($block_q)) {
    $blocks[] = $b;
}


$currNav = "Block Time";
require_once("includes/header.php");
?>

<section>

    <div class="sub-header">
        <h1>Block</h1>

        <button class="button btn-dark-grey medium has-icon" data-toggle-form="toggleForm">
            <i class="fas fa-plus"></i>
            <span>Add Block</span>
        </button>
    </div>


    <form method="POST" action="block_time.php" id="toggleForm" class="toggle-form <?= isset($_GET['date']) ? 'is-expanded' : '' ?>">
        <div class="columns">
            <div class="column is-one-third">
                <div class="field">
                    <label class="label">Start Date</label>
                    <input class="input" type="date" name="unavailable_date_start" value="<?= htmlspecialchars($prefillDate) ?>" required>
                </div>
            </div>

            <div class="column is-one-third">
                <div class="field">
                    <label class="label">End Date</label>
                    <input class="input" type="date" name="unavailable_date_end" value="<?= htmlspecialchars($prefillDate) ?>">
                </div>
            </div>

            <div class="column is-one-third">
                <div class="field">
                    <label class="label">Band Member</label>
                    <div class="select">
                        <select name="member_id" required>
                            <option value="">Select...</option>
                            <?php foreach ($members as $m): ?>
                                <option value="<?= $m['id'] ?>"><?= htmlspecialchars($m['name']) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>
            </div>
        </div>

        <div class="field">
            <label class="label">Reason (optional)</label>
            <input class="input" type="text" name="reason" placeholder="Out of town, recording, etc.">
        </div>

        <div class="field is-grouped">
            <button class="button btn-primary" type="submit">Save Block</button>
            <button class="button btn-grey" type="button" data-cancel-form="toggleForm">Cancel</button>
        </div>
    </form>


    <table class="table is-striped is-fullwidth">
        <thead>
            <tr>
                <th>Date</th>
                <th>Member</th>
                <th>Reason</th>
                <th></th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($blocks as $b): ?>
                <tr id="<?= str_replace('-', '', $b['unavailable_date']) ?>">
                    <td><?= date('M j, Y', strtotime($b['unavailable_date'])) ?></td>
                    <td><?= htmlspecialchars($b['member']) ?></td>
                    <td><?= htmlspecialchars($b['reason']) ?></td>
                    <td>
                        <a href="block_time.php?del=1&id=<?= $b['id'] ?>" title="Delete">
                            <i class="fas fa-times" style="color: #ce4257; font-size: 1.25rem;"></i>
                        </a>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>

</section>

<script>
window.addEventListener('DOMContentLoaded', () => {
    const hash = window.location.hash.replace('#', '');
    const target = document.getElementById(`${hash.replaceAll('-', '')}`);

    if (target) {
        const offset = 50;
        const topPos = target.getBoundingClientRect().top + window.pageYOffset - offset;

        window.scrollTo({
            top: topPos,
            behavior: 'smooth'
        });

        target.classList.add('highlight');
    }
});
</script>

<?php require_once("includes/footer.php"); ?>
