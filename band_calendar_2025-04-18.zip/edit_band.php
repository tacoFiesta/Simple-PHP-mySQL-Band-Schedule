<?php
// File: /edit_band.php

require_once("includes/constants.php");
require_once("includes/connection.php");
require_once("includes/functions.php");

$band_id = (int) ($_GET['id'] ?? 0);

if ($band_id < 1) {
    die("Invalid band ID.");
}


////////////////////////////////////////////////
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $band_id      = (int) ($_POST['id'] ?? 0);
    $name         = trim($_POST['name'] ?? '');
    $city         = trim($_POST['city'] ?? '');
    $state        = trim($_POST['state'] ?? '');
    $contact_info = trim($_POST['contact_info'] ?? '');

    if ($band_id < 1 || $name === '') {
        header("Location: band_list.php");
        exit;
    }

    $stmt = mysqli_prepare($link, "
        UPDATE bands
        SET name = ?, city = ?, state = ?, contact_info = ?
        WHERE id = ?
        LIMIT 1
    ");

    if ($stmt) {
        mysqli_stmt_bind_param($stmt, "ssssi", $name, $city, $state, $contact_info, $band_id);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_close($stmt);
    }

    header("Location: band_list.php");
    exit;
}


////////////////////////////////////////////////
// Fetch band from DB

$sql = "SELECT id, name, city, state, contact_info FROM bands WHERE id = $band_id LIMIT 1";
$res = mysqli_query($link, $sql);
$bandData = mysqli_fetch_assoc($res);

if (!$bandData) {
    die("Band not found.");
}

$currNav = "Edit Band";
require_once("includes/header.php");
?>

<section>

    <div class="sub-header">
        <h1>Edit Band</h1>
    </div>

    <form method="POST" action="edit_band.php?id=<?php echo $bandData['id']; ?>">
        <input type="hidden" name="id" value="<?php echo $bandData['id']; ?>">

        <div class="field">
            <label class="label">Name</label>
            <div class="control">
                <input class="input" type="text" name="name"
                       value="<?php echo htmlspecialchars($bandData['name'] ?? ''); ?>"
                       required>
            </div>
        </div>

        <div class="field">
            <label class="label">City</label>
            <div class="control">
                <input class="input" type="text" name="city"
                       value="<?php echo htmlspecialchars($bandData['city'] ?? ''); ?>">
            </div>
        </div>

        <div class="field">
            <label class="label">State</label>
            <div class="control">
                <input class="input" type="text" name="state"
                       value="<?php echo htmlspecialchars($bandData['state'] ?? ''); ?>">
            </div>
        </div>

        <div class="field">
            <label class="label">Contact Info</label>
            <div class="control">
                <input class="input" type="text" name="contact_info"
                       value="<?php echo htmlspecialchars($bandData['contact_info'] ?? ''); ?>">
            </div>
        </div>

        <div class="field is-grouped mt-4">
            <div class="control">
                <button type="submit" class="button btn-primary">Save</button>
            </div>
            <div class="control">
                <a href="band_list.php" class="button is-light">Cancel</a>
            </div>
        </div>
    </form>

</section>

<?php
require_once("includes/footer.php");
