<?php
// File: /new_show.php
require_once("includes/constants.php");
require_once("includes/connection.php");
require_once("includes/functions.php");

$getDate = '';
if (isset($_GET['date'])) {
    $getDate = $_GET['date'];
}


////////////////////////////////////////////////
// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $show_date  = $_POST['show_date'] ?? '';
    $show_time  = $_POST['show_time'] ?? '';
    $venue_id   = (int)($_POST['venue_id'] ?? 0);
    $venue_name = trim($_POST['venue_name'] ?? '');

    // Insert new venue if needed
    if ($venue_id === 0 && $venue_name !== '') {
        $stmtVenue = mysqli_prepare($link, "INSERT INTO venues (name) VALUES (?)");
        mysqli_stmt_bind_param($stmtVenue, "s", $venue_name);
        mysqli_stmt_execute($stmtVenue);
        $venue_id = mysqli_insert_id($link);
        mysqli_stmt_close($stmtVenue);
    }

    // Insert the new show
    $stmtShow = mysqli_prepare($link, "
        INSERT INTO shows (show_date, show_time, venue_id)
        VALUES (?, ?, ?)
    ");
    mysqli_stmt_bind_param($stmtShow, "ssi", $show_date, $show_time, $venue_id);
    mysqli_stmt_execute($stmtShow);
    $new_id = mysqli_insert_id($link);
    mysqli_stmt_close($stmtShow);

    // Redirect to edit page
    header("Location: edit_show.php?id=$new_id");
    exit;
}


$currNav = "New Show";
require_once("includes/header.php");
?>

<section>

    <div class="sub-header">
        <h1>New Show</h1>
    </div>

    <form method="POST" action="new_show.php" onsubmit="return validateVenue();">

        <div class="columns">

            <div class="column">
                <div class="field">
                    <label class="label">Show Date</label>
                    <div class="control">
                        <input class="input" type="date" name="show_date" required value="<?php echo $getDate; ?>">
                    </div>
                </div>
            </div>

            <div class="column">
                <div class="field">
                    <label class="label">Show Time</label>
                    <div class="control">
                        <input class="input" type="time" name="show_time" value="21:00">
                    </div>
                </div>
            </div>

        </div>

        <!-- Venue Autocomplete -->
        <div class="field">
            <label class="label">Venue</label>
            <div id="venueDisplay" class="venue-display"></div>
        </div>

        <div style="position: relative;">
            <input id="venueSearch" name="venue_name" class="input" type="text" placeholder="Type venue name...">
            <input id="venue_id" type="hidden" name="venue_id" value="">
            <div id="venueSuggestions" class="autocomplete-suggestions" style="display: none;"></div>
        </div>

        <br>

        <div class="field is-grouped">
            <div class="control">
                <button type="submit" class="button btn-primary">Create Show</button>
            </div>
            <div class="control">
                <a href="index.php" class="button is-light">Cancel</a>
            </div>
        </div>

    </form>

</section>

<?php
require_once("includes/footer.php");
