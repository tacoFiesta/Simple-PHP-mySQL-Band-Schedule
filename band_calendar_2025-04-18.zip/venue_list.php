<?php
// File: /venue_list.php
require_once("includes/constants.php");
require_once("includes/connection.php");
require_once("includes/functions.php");


////////////////////////////////////////////////
// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name     = trim($_POST['name'] ?? '');
    $address  = trim($_POST['address'] ?? '');
    $city     = trim($_POST['city'] ?? '');
    $state    = trim($_POST['state'] ?? '');
    $zip_code = trim($_POST['zip_code'] ?? '');

    if ($name !== '') {
        $stmt = mysqli_prepare($link, "
            INSERT INTO venues (name, address, city, state, zip_code)
            VALUES (?, ?, ?, ?, ?)
        ");
        mysqli_stmt_bind_param($stmt, "sssss", $name, $address, $city, $state, $zip_code);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_close($stmt);
    }

    header("Location: venue_list.php");
    exit;
}


////////////////////////////////////////////////
// Sorting setup
$allowedSorts = ['name', 'city', 'state', 'zip_code'];
$sort = $_GET['sort'] ?? 'name';
$dir  = strtolower($_GET['dir'] ?? 'asc');

if (!in_array($sort, $allowedSorts)) {
    $sort = 'name';
}
if (!in_array($dir, ['asc', 'desc'])) {
    $dir = 'asc';
}

$nextDir = $dir === 'asc' ? 'desc' : 'asc';


////////////////////////////////////////////////
// Fetch venues
$query = "SELECT id, name, address, city, state, zip_code FROM venues ORDER BY $sort $dir";
$result = mysqli_query($link, $query);

$venues = [];
while ($row = mysqli_fetch_assoc($result)) {
    $venues[] = $row;
}


$currNav = "Venue List";
require_once("includes/header.php");
?>

<section>

    <div class="sub-header">
        <h1>Venues</h1>
        <button class="button btn-dark-grey medium has-icon" data-toggle-form="toggleForm">
            <i class="fas fa-plus"></i> <span>Add Venue</span>
        </button>
    </div>

    <form method="POST" action="venue_list.php" id="toggleForm" class="toggle-form">

        <div class="field">
            <label class="label">Venue Name</label>
            <div class="control">
                <input class="input" type="text" name="name" required>
            </div>
        </div>

        <div class="field">
            <label class="label">Address</label>
            <div class="control">
                <input class="input" type="text" name="address">
            </div>
        </div>

        <div class="columns">
            <div class="column">
                <div class="field">
                    <label class="label">City</label>
                    <div class="control">
                        <input class="input" type="text" name="city">
                    </div>
                </div>
            </div>

            <div class="column">
                <div class="field">
                    <label class="label">State</label>
                    <div class="control">
                        <input class="input" type="text" name="state">
                    </div>
                </div>
            </div>

            <div class="column">
                <div class="field">
                    <label class="label">Zip Code</label>
                    <div class="control">
                        <input class="input" type="text" name="zip_code">
                    </div>
                </div>
            </div>
        </div>

        <div class="field is-grouped">
            <button class="button btn-primary" type="submit">Save Venue</button>
            <button class="button btn-grey" type="button" data-cancel-form="toggleForm">Cancel</button>
        </div>

    </form>

    <div class="table-wrapper">
        <table class="table is-striped is-fullwidth">
            <thead>
                <tr>
                    <th>
                        <a href="?sort=name&dir=<?php echo ($sort === 'name') ? $nextDir : 'asc'; ?>">
                            Name <i class="fas <?php echo sortIcon('name', $sort, $dir); ?>"></i>
                        </a>
                    </th>
                    <th></th>
                    <th>
                        <a href="?sort=city&dir=<?php echo ($sort === 'city') ? $nextDir : 'asc'; ?>">
                            City <i class="fas <?php echo sortIcon('city', $sort, $dir); ?>"></i>
                        </a>
                    </th>
                    <th>
                        <a href="?sort=state&dir=<?php echo ($sort === 'state') ? $nextDir : 'asc'; ?>">
                            State <i class="fas <?php echo sortIcon('state', $sort, $dir); ?>"></i>
                        </a>
                    </th>
                    <th></th>
                </tr>
            </thead>

            <tbody>
                <?php if (count($venues) === 0): ?>
                    <tr>
                        <td colspan="4"><em>No venues found.</em></td>
                    </tr>
                <?php else: ?>
                    <?php foreach ($venues as $v): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($v['name']); ?></td>
                            <td>
                                <?php 
                                $mapLink = str_replace(' ', '+',
                                    htmlspecialchars($v['address'] ?? '') . " " .
                                    htmlspecialchars($v['city'] ?? '') . " " .
                                    htmlspecialchars($v['state'] ?? '') . " " .
                                    htmlspecialchars($v['zip_code'] ?? '')
                                );
                                ?>
                                <a href="https://www.google.com/maps/place/<?php echo $mapLink; ?>" target="_blank">map</a>
                                <span class="hide-mobile"> - <?php echo htmlspecialchars($v['address'] ?? ''); ?></span>
                            </td>
                            <td colspan="2">
                                <?php echo htmlspecialchars($v['city'] ?? ''); ?>
                                <?php echo htmlspecialchars($v['state'] ?? ''); ?>
                                <?php echo htmlspecialchars($v['zip_code'] ?? ''); ?>
                            </td>
                            <td>
                                <a href="edit_venue.php?id=<?php echo $v['id']; ?>" class="button btn-accent small">Edit</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

</section>

<?php require_once("includes/footer.php"); ?>
